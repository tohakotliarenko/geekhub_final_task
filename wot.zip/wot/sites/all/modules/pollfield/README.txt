POLLFIELD

This module creates a CCK field enabling multiple types of user polls.
Pollfields can be added to multiple content types.

Pollfield questions, results, status, runtime, and vote tallies
can all be exposed in Views.

Because of these features and others, pollfiled provides a more flexible
polling option than the Drupal core poll module.

@TODO@
Update this README to match the gudielines at http://drupal.org/node/161085
