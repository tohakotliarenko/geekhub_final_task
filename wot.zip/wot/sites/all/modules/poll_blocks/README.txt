Install:
--------
http://drupal.org/documentation/install/modules-themes/modules-7

Usage:
------
Add polls. Goto admin/structure/block and manage Poll blocks.
